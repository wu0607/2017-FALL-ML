#!/bin/bash

a=$(pip2 install --user numpy)
python kdtree.py $1 $2


